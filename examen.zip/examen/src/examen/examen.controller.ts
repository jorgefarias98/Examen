import { Controller, Get, Render } from '@nestjs/common';
import { relative } from 'node:path/win32';

@Controller('examen')
export class ExamenController {
    @Get()
    @Render('index')
    rodo(){
        return 
    }
}
